<?php
	if(!isset($_POST['email']) || !isset($_POST['pass']) || !isset($_POST['name']) || !isset($_POST['twitter']) ){
		echo "ERROR1";
		exit(1);
	}else{
		$name = $_POST['name'];
		$pass = strtoupper($_POST['pass']);
		$email = $_POST['email'];
		$twitter = $_POST['twitter'];
		
		$strJson = '{"Name":"' . $name . '", "Email":"' . $email . '", "Pass":"' . $pass . '", "Twitter":"' . $twitter . '"}';
		//$strJson = "Bienvenido " . $name . ", estamos encantado de tenerte con nosotros en nuestra pagina ";
		$gestor = fopen("./text.json", "w");
		
		if( $gestor === false ){
			echo "ERROR2";
			exit(1);
		}
		
		
		if( fwrite( $gestor, $strJson) === false){
			echo "ERROR3";
			exit(1);
		}
		
		echo "OK";
		
	}
	
	exec('commit');
?>
