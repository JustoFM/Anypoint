function AJAX() {
	if (window.XMLHttpRequest){
			//El explorador implementa la interfaz de forma nativa
			return new XMLHttpRequest();
	} 
	else if (window.ActiveXObject){
			//El explorador permite crear objetos ActiveX
			try {
					return new ActiveXObject("MSXML2.XMLHTTP");
			} catch (e) {
					try {
							return new ActiveXObject("Microsoft.XMLHTTP");
					} catch (e) {}
			}
	}
	alert("No ha sido posible crear una instancia de XMLHttpRequest");
	return null;
}