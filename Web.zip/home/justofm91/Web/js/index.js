function close_alert(campo){
	var panel;
	if(campo.name == "alert-login")
		panel = document.getElementById('alert-message-login');
	else if(campo.name == "alert-registro")
		panel = document.getElementById('alert-message-registro');
	panel.style.display = "none";
}

function desplegar_registro(){
	var panel = document.getElementById('registro-desplegable');
	
	if(panel.style.display == "none")
		panel.style.display = "block"
	else
		panel.style.display = "none"
}

function check_email(){
	var email = document.getElementById('strEmail').value;
	
	if(check_email_sintax(email)){
		document.getElementById('alert-text-email-format').style.display = "none";
		check_alert_display();
		return true;
	}
	else{
		document.getElementById('alert-text-email-format').style.display = "block";
		check_alert_display();
		return false;
	}
}

function check_email_sintax(email){
	sintaxisEmail = new RegExp("([a-z]|[0-9]|\.|_|\-)@([a-z]).([a-z]{2,4})");
	
	if(!sintaxisEmail.test(email))
		return false;
	return true;
}

function check_password(){
	var pass = document.getElementById('strPass').value;
	
	if(pass.length < 6){
		document.getElementById('alert-text-pass-lenght').style.display = "block";
		check_alert_display();
		return false;
	}else{
		document.getElementById('alert-text-pass-lenght').style.display = "none";
		check_alert_display();
		return true;
	}
}

function check_password_confirm(){
	var pass = document.getElementById('strPass').value;
	var pass2 = document.getElementById('strPass2').value;
	
	if(pass.length >= 6 && pass2.length >= 6 && pass == pass2){
		document.getElementById('alert-text-pass-not-match').style.display = "none";
		check_alert_display();
		return true;
	}else{
		document.getElementById('alert-text-pass-not-match').style.display = "block";
		check_alert_display();
		return false;
	}
}

function check_form(){
	var ok = true;
	if(!check_email())
		ok = false;
	if(!check_password())
		ok = false;
	if(!check_password_confirm())
		ok = false;
	if(ok)
		return true;
	else
		return false;
}

function check_alert_display(){
	var panel = document.getElementById('alert-message-registro');
	var mostrando = false;
	for(var i=0 ; i<panel.children.length ; i++){
		if(panel.children.name != "alert-registro" && panel.children[i].style.display == "block"){
			mostrando = true;
			break;
		}
	}
	if(!mostrando)
		panel.style.display = "none";
	else
		panel.style.display = "block";
}

function send_register(){
	if(check_form()){
		//enviar los datos por ajax
		var ajax = AJAX();
		var resultado;
		
		ajax.open("POST", "./php/registro.php");
		ajax.onreadystatechange = function(){
			if (ajax.readyState == 4){
				resultado = ajax.responseText;
				console.log(resultado);
				if(resultado == "OK")
					alert("\u00A1ENHORABUENA! su cuenta ha sido creada con \u00e9xito.");
				else
					alert("\u00A1Ha ocurrido un error durante el envío de los datos, vuelva a intentarlo mas tarde!");
			}
		}
		ajax.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		ajax.send("email=" + document.getElementById('strEmail').value +
		"&pass=" + MD5(document.getElementById('strPass').value) +
		"&name=" + document.getElementById('strName').value +
        "&twitter=" + document.getElementById('strTwitter').value );
	}
}

//var strJson = '{"Name":"' + name + '", "Email":"' + email + '", "Pass":"' + MD5(pass) + '", "Twitter":"' + twitter + '"}';
